#include <WiFi.h>
#include <WiFiManager.h>
#include <FirebaseESP32.h>
#include <LiquidCrystal_I2C.h>
#include <Wire.h>
#include "SD.h"
#include "DHT.h"
#include "time.h"

// ================== Firebase ==================
#define FIREBASE_HOST "baochay-8ae78-default-rtdb.firebaseio.com"
#define FIREBASE_AUTH "GpCAUMOaGg8y7LyY7g4ogpAqOwfU20CJIBgVHbfo"

FirebaseData fbdo;
FirebaseAuth auth;
FirebaseConfig config;

// ================== Pin config ==================
#define ALARM_PIN 2    // LED báo chế độ cảnh báo
#define BUZZER_PIN 4   // Còi cảnh báo
#define DHT_PIN 15
#define DHT_TYPE DHT11
#define GAS_PIN 34

// ================== LCD ==================
#define LCD_ADDR 0x27
#define LCD_COLS 16
#define LCD_ROWS 2
#define SDA_PIN 18
#define SCL_PIN 19
LiquidCrystal_I2C lcd(LCD_ADDR, LCD_COLS, LCD_ROWS);

// ================== Global variables ==================
float g_temperature = 0;
float g_humidity = 0;
int g_gas = 0;
int g_status = 0;        // 0 = an toàn, 1 = cháy
int g_alarmControl = 0;  // 0 = off, 1 = on

unsigned long lastSendTime = 0;
const unsigned long interval = 5000;  // 5 giây

// Biến thời gian để xử lý còi và khí gas
unsigned long gasHighStartTime = 0;     // thời điểm bắt đầu >50
unsigned long gasSafeStartTime = 0;     // thời điểm trở lại an toàn
bool gasHigh = false;                   // trạng thái khí gas cao
bool buzzerActive = false;              // còi đang kêu

// ================== NTP ==================
const char* ntpServer = "pool.ntp.org";
const long gmtOffset_sec = 7 * 3600;
const int daylightOffset_sec = 0;

DHT dht(DHT_PIN, DHT_TYPE);

// ================== Time functions ==================
String getDateTimeKey() {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) return "0000-00-00_00-00-00";
  char buf[20];
  strftime(buf, sizeof(buf), "%Y-%m-%d_%H-%M-%S", &timeinfo);
  return String(buf);
}

String getDateTimeString() {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) return "0000-00-00 00:00:00";
  char buf[20];
  strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &timeinfo);
  return String(buf);
}

// ================== Sensor ==================
void readSensors() {
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();
  int gasValue = analogRead(GAS_PIN);

  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("Loi doc DHT11");
    return;
  }

  g_temperature = temperature;
  g_humidity = humidity;
  g_gas = map(gasValue, 0, 4095, 0, 100);

  // Kiểm tra khí gas
  if (g_gas > 50) {
    if (!gasHigh) {
      gasHigh = true;
      gasHighStartTime = millis();
    } else if (millis() - gasHighStartTime >= 5000) {
      g_status = 1; // cháy
      buzzerActive = true;
      gasSafeStartTime = 0;
    }
  } else {
    if (gasHigh) {
      gasHigh = false;
      gasSafeStartTime = millis();
    }
    if (buzzerActive && gasSafeStartTime != 0 && millis() - gasSafeStartTime >= 7000) {
      buzzerActive = false;
    }
    g_status = 0; // an toàn
  }

  // Cập nhật LCD
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("T:");
  lcd.print(g_temperature, 1);
  lcd.print("C H:");
  lcd.print(g_humidity, 0);
  lcd.print("%");

  lcd.setCursor(0, 1);
  if (g_gas > 50)
    lcd.printf("GAS:%d%% CO GAS!", g_gas);
  else if (g_status == 1)
    lcd.printf("GAS:%d%% FIRE!", g_gas);
  else
    lcd.printf("GAS:%d%% SAFE", g_gas);

  // Điều khiển còi
  if (buzzerActive) {
    digitalWrite(BUZZER_PIN, HIGH);
  } else {
    digitalWrite(BUZZER_PIN, LOW);
  }
}

// ================== Firebase ==================
void sendDataToFirebase(String device) {
  String path = "/fire_alarm/" + device;

  Firebase.RTDB.setFloat(&fbdo, path + "/temperature", g_temperature);
  Firebase.RTDB.setFloat(&fbdo, path + "/humidity", g_humidity);
  Firebase.RTDB.setInt(&fbdo, path + "/gas", g_gas);
  Firebase.RTDB.setInt(&fbdo, path + "/status", g_status);

  String timestampKey = getDateTimeKey();
  String timestampStr = getDateTimeString();
  String pathHistory = path + "/history/" + timestampKey;
  Firebase.RTDB.setFloat(&fbdo, pathHistory + "/temperature", g_temperature);
  Firebase.RTDB.setFloat(&fbdo, pathHistory + "/humidity", g_humidity);
  Firebase.RTDB.setInt(&fbdo, pathHistory + "/gas", g_gas);
  Firebase.RTDB.setInt(&fbdo, pathHistory + "/status", g_status);
  Firebase.RTDB.setString(&fbdo, pathHistory + "/time", timestampStr);

  Serial.printf("[%s] Temperature=%.1f Humidity=%.1f GAS=%d STATUS=%d %s\n",
                device.c_str(), g_temperature, g_humidity, g_gas, g_status, timestampStr.c_str());
}

// ================== Alarm ==================
void checkAlarmCommand(String device) {
  String path = "/fire_alarm/" + device + "/alarmControl";
  if (Firebase.RTDB.getInt(&fbdo, path)) {
    g_alarmControl = fbdo.intData();

    if (g_alarmControl == 1) {
      digitalWrite(ALARM_PIN, HIGH);
      Serial.printf("[%s] Alarm ON (status=%d)\n", device.c_str(), g_status);
    } else {
      digitalWrite(ALARM_PIN, LOW);
      Serial.printf("[%s] Alarm OFF\n", device.c_str());
    }
  }
}

// ================== Setup ==================
void setup() {
  Serial.begin(115200);
  pinMode(ALARM_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(ALARM_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  dht.begin();
  Wire.begin(SDA_PIN, SCL_PIN);
  lcd.init();
  lcd.backlight();

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Dang k/noi wifi ");

  // WiFiManager
  WiFiManager wm;
  if (!wm.autoConnect("ESP32_FireAlarm")) {
    Serial.println("Khong ket noi WiFi, reset...");
    delay(3000);
    ESP.restart();
  }
  Serial.println("WiFi connected: " + WiFi.localIP().toString());

  // Firebase
  config.host = FIREBASE_HOST;
  config.signer.tokens.legacy_token = FIREBASE_AUTH;
  Firebase.begin(&config, &auth);
  Firebase.reconnectWiFi(true);

  // NTP-78
  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
  Serial.println("Waiting for time...");
  struct tm timeinfo;
  while (!getLocalTime(&timeinfo)) {
    delay(100);
    Serial.print(".");  
  }
  Serial.println("Got time");
}

// ================== Loop ==================
void loop() {
  readSensors();

  unsigned long currentMillis = millis();
  if (currentMillis - lastSendTime >= interval) {
    lastSendTime = currentMillis;
    sendDataToFirebase("HNMU2");
  }

  checkAlarmCommand("HNMU2");
}