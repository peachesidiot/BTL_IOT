// firebase-config.js
const firebaseConfig = {
  apiKey: "AIzaSyD397rcD8pNIk6VpJHeyRzBGOhEc2qAtYA",
  authDomain: "baochay-8ae78.firebaseapp.com",
  databaseURL: "https://baochay-8ae78-default-rtdb.firebaseio.com",
  projectId: "baochay-8ae78",
  storageBucket: "baochay-8ae78.appspot.com",
  messagingSenderId: "91624278521",
  appId: "1:91624278521:web:10cf8c2179308800685528"
};
